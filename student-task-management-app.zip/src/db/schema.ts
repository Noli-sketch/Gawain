import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  index,
  pgEnum,
  time,
} from "drizzle-orm/pg-core";

export const priorityEnum = pgEnum("priority", [
  "low",
  "medium",
  "high",
  "urgent",
]);
export const taskStatusEnum = pgEnum("task_status", [
  "todo",
  "in_progress",
  "done",
]);
export const taskTypeEnum = pgEnum("task_type", [
  "assignment",
  "exam",
  "quiz",
  "project",
  "report",
  "reading",
  "other",
]);
export const dayOfWeekEnum = pgEnum("day_of_week", [
  "M",
  "T",
  "W",
  "TH",
  "F",
  "SA",
  "SU",
]);
export const eventTypeEnum = pgEnum("event_type", [
  "class",
  "exam",
  "deadline",
  "holiday",
  "personal",
]);

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  university: text("university").notNull(),
  course: text("course").notNull(),
  yearLevel: text("year_level").notNull(),
  semester: text("semester").notNull().default("1st Semester, AY 2025-2026"),
  avatarColor: text("avatar_color").notNull().default("#6366f1"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("sessions_user_idx").on(t.userId),
  }),
);

export const classes = pgTable(
  "classes",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    name: text("name").notNull(),
    professor: text("professor").notNull(),
    room: text("room").notNull(),
    color: text("color").notNull(),
    units: integer("units").notNull().default(3),
    archived: boolean("archived").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("classes_user_idx").on(t.userId),
  }),
);

export const classSchedules = pgTable(
  "class_schedules",
  {
    id: text("id").primaryKey(),
    classId: text("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    dayOfWeek: dayOfWeekEnum("day_of_week").notNull(),
    startTime: time("start_time", { withTimezone: false }).notNull(),
    endTime: time("end_time", { withTimezone: false }).notNull(),
    roomOverride: text("room_override"),
  },
  (t) => ({
    classIdx: index("class_schedules_class_idx").on(t.classId),
  }),
);

export const tasks = pgTable(
  "tasks",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    classId: text("class_id").references(() => classes.id, {
      onDelete: "set null",
    }),
    title: text("title").notNull(),
    description: text("description"),
    type: taskTypeEnum("type").notNull().default("assignment"),
    priority: priorityEnum("priority").notNull().default("medium"),
    status: taskStatusEnum("status").notNull().default("todo"),
    dueDate: timestamp("due_date").notNull(),
    completedAt: timestamp("completed_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("tasks_user_idx").on(t.userId),
    dueIdx: index("tasks_due_idx").on(t.dueDate),
  }),
);

export const events = pgTable(
  "events",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    classId: text("class_id").references(() => classes.id, {
      onDelete: "set null",
    }),
    title: text("title").notNull(),
    description: text("description"),
    type: eventTypeEnum("type").notNull().default("personal"),
    startAt: timestamp("start_at").notNull(),
    endAt: timestamp("end_at").notNull(),
    allDay: boolean("all_day").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("events_user_idx").on(t.userId),
  }),
);

export type User = typeof users.$inferSelect;
export type Class = typeof classes.$inferSelect;
export type ClassSchedule = typeof classSchedules.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Event = typeof events.$inferSelect;
