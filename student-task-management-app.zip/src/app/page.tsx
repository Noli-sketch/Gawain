import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";

export default async function Home() {
  const { user } = await getCurrentSession();
  if (user) {
    redirect("/dashboard");
  }
  redirect("/login");
}
