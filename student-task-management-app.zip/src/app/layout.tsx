import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TaskWise - Task Manager for Filipino Students",
  description: "Stay organized with automatic schedule importing and smart task management",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
