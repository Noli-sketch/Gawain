import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { ScheduleClient } from "./ScheduleClient";

export default async function SchedulePage() {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");
  return <ScheduleClient user={user} />;
}
