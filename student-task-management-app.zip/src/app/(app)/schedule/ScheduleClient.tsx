"use client";

import { useEffect, useState } from "react";
import { Plus, Clock } from "lucide-react";
import type { User, Class, ClassSchedule } from "@/db/schema";
import { formatTimeRange, dayLabel, dayShort } from "@/lib/utils";

type ClassWithSchedule = Class & { schedules: ClassSchedule[] };

export function ScheduleClient({ user }: { user: User }) {
  const [classes, setClasses] = useState<ClassWithSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/schedule")
      .then((r) => r.json())
      .then((d) => {
        setClasses(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const days = ["M", "T", "W", "TH", "F", "SA"];
  const hours = Array.from({ length: 14 }, (_, i) => i + 7); // 7 AM to 8 PM

  function getSlotsForDay(day: string) {
    const slots: Array<{
      class: Class;
      schedule: ClassSchedule;
    }> = [];
    for (const cls of classes) {
      for (const sched of cls.schedules) {
        if (sched.dayOfWeek === day) {
          slots.push({ class: cls, schedule: sched });
        }
      }
    }
    return slots.sort((a, b) => a.schedule.startTime.localeCompare(b.schedule.startTime));
  }

  function timeToMinutes(time: string): number {
    const [h, m] = time.split(":").map(Number);
    return h * 60 + m;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Schedule</h1>
          <p className="text-slate-600 mt-1">Your weekly class schedule</p>
        </div>
        <a
          href="/classes"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg font-medium hover:from-indigo-600 hover:to-purple-700 transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Manage Classes
        </a>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 animate-pulse">
          <div className="h-96 bg-slate-200 rounded" />
        </div>
      ) : classes.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 text-slate-400 mb-4">
            <Clock className="w-8 h-8" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-1">No classes yet</h3>
          <p className="text-slate-500 text-sm mb-4">
            Add your classes to see your weekly schedule
          </p>
          <a
            href="/classes"
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4" />
            Add Class
          </a>
        </div>
      ) : (
        <>
          {/* Desktop grid view */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="grid grid-cols-7 border-b border-slate-200">
              <div className="p-3 bg-slate-50 border-r border-slate-200" />
              {days.map((day) => (
                <div
                  key={day}
                  className="p-3 text-center font-semibold text-slate-700 bg-slate-50 border-r border-slate-200 last:border-r-0"
                >
                  {dayShort(day)}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              <div className="border-r border-slate-200">
                {hours.map((h) => (
                  <div
                    key={h}
                    className="h-20 border-b border-slate-100 p-2 text-xs text-slate-400"
                  >
                    {h === 12 ? "12 PM" : h > 12 ? `${h - 12} PM` : `${h} AM`}
                  </div>
                ))}
              </div>
              {days.map((day) => {
                const slots = getSlotsForDay(day);
                return (
                  <div key={day} className="relative border-r border-slate-200 last:border-r-0">
                    {hours.map((h) => (
                      <div key={h} className="h-20 border-b border-slate-100" />
                    ))}
                    {slots.map(({ class: cls, schedule }) => {
                      const startMin = timeToMinutes(schedule.startTime);
                      const endMin = timeToMinutes(schedule.endTime);
                      const topPx = ((startMin - 7 * 60) / 60) * 80;
                      const heightPx = ((endMin - startMin) / 60) * 80;
                      return (
                        <div
                          key={schedule.id}
                          className="absolute left-1 right-1 rounded-lg p-2 text-white text-xs overflow-hidden"
                          style={{
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            backgroundColor: cls.color,
                          }}
                        >
                          <div className="font-semibold truncate">{cls.code}</div>
                          <div className="opacity-90 truncate">
                            {formatTimeRange(schedule.startTime, schedule.endTime)}
                          </div>
                          <div className="opacity-75 truncate mt-1">{cls.room}</div>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Mobile list view */}
          <div className="md:hidden space-y-4">
            {days.map((day) => {
              const slots = getSlotsForDay(day);
              if (slots.length === 0) return null;
              return (
                <div key={day} className="bg-white rounded-xl border border-slate-200 p-4">
                  <h3 className="font-semibold text-slate-900 mb-3">{dayLabel(day)}</h3>
                  <div className="space-y-2">
                    {slots.map(({ class: cls, schedule }) => (
                      <div
                        key={schedule.id}
                        className="flex items-center gap-3 p-3 rounded-lg"
                        style={{ backgroundColor: cls.color + "15" }}
                      >
                        <div
                          className="w-1 h-12 rounded-full"
                          style={{ backgroundColor: cls.color }}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-slate-900">{cls.code}</div>
                          <div className="text-sm text-slate-600">{cls.name}</div>
                          <div className="text-xs text-slate-500 mt-1">
                            {formatTimeRange(schedule.startTime, schedule.endTime)} ·{" "}
                            {cls.room}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
