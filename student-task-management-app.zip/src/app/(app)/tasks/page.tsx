import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { TasksClient } from "./TasksClient";

export default async function TasksPage() {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");
  return <TasksClient user={user} />;
}
