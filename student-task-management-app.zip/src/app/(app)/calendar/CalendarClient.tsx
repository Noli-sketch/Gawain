"use client";

import { useEffect, useState, useRef } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Upload,
  Calendar as CalIcon,
  Trash2,
  Loader2,
} from "lucide-react";
import type { User, Event, Class } from "@/db/schema";
import { toast } from "@/components/Toaster";

type EventWithClass = Event & { class: Class | null };

export function CalendarClient({ user }: { user: User }) {
  const [current, setCurrent] = useState(new Date());
  const [events, setEvents] = useState<EventWithClass[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selected, setSelected] = useState<EventWithClass | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const year = current.getFullYear();
  const month = current.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch(`/api/events?start=${new Date(year, month, 1).toISOString()}&end=${new Date(year, month + 1, 0).toISOString()}`).then(
        (r) => r.json(),
      ),
      fetch("/api/classes").then((r) => r.json()),
    ])
      .then(([e, c]) => {
        setEvents(e);
        setClasses(c);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [year, month]);

  async function handleImportICS(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/events", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error();
      toast(`Imported ${data.imported} events from calendar`);
      // Reload
      const refreshed = await fetch(
        `/api/events?start=${new Date(year, month, 1).toISOString()}&end=${new Date(year, month + 1, 0).toISOString()}`,
      ).then((r) => r.json());
      setEvents(refreshed);
    } catch {
      toast("Failed to import calendar", "error");
    }
    setImporting(false);
    if (fileInput.current) fileInput.current.value = "";
  }

  async function deleteEvent(id: string) {
    if (!confirm("Delete this event?")) return;
    setEvents((prev) => prev.filter((e) => e.id !== id));
    setSelected(null);
    try {
      await fetch(`/api/events/${id}?id=${id}`, { method: "DELETE" });
      toast("Event deleted");
    } catch {
      toast("Failed to delete", "error");
    }
  }

  function getEventsForDay(day: number) {
    return events.filter((e) => {
      const d = new Date(e.startAt);
      return d.getDate() === day && d.getMonth() === month && d.getFullYear() === year;
    });
  }

  const monthName = current.toLocaleDateString("en-PH", {
    month: "long",
    year: "numeric",
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Calendar</h1>
          <p className="text-slate-600 mt-1">View and import your events</p>
        </div>
        <div className="flex gap-2">
          <input
            ref={fileInput}
            type="file"
            accept=".ics"
            onChange={handleImportICS}
            className="hidden"
          />
          <button
            onClick={() => fileInput.current?.click()}
            disabled={importing}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-all disabled:opacity-50"
          >
            {importing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Upload className="w-4 h-4" />
            )}
            Import .ics
          </button>
          <button
            onClick={() => {
              setSelected(null);
              setShowModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg font-medium hover:from-indigo-600 hover:to-purple-700 transition-all shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add Event
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="p-4 md:p-6 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">{monthName}</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrent(new Date(year, month - 1, 1))}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrent(new Date())}
              className="px-3 py-1.5 text-sm rounded-lg hover:bg-slate-100"
            >
              Today
            </button>
            <button
              onClick={() => setCurrent(new Date(year, month + 1, 1))}
              className="p-2 rounded-lg hover:bg-slate-100"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 border-b border-slate-200">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div
              key={d}
              className="p-3 text-center text-xs font-semibold text-slate-500 bg-slate-50 border-r border-slate-200 last:border-r-0"
            >
              {d}
            </div>
          ))}
        </div>

        {loading ? (
          <div className="p-12 text-center text-slate-500">Loading...</div>
        ) : (
          <div className="grid grid-cols-7">
            {Array.from({ length: firstDay }).map((_, i) => (
              <div
                key={`empty-${i}`}
                className="min-h-[100px] p-2 border-r border-b border-slate-200 bg-slate-50"
              />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const dayEvents = getEventsForDay(day);
              const isToday =
                new Date().getDate() === day &&
                new Date().getMonth() === month &&
                new Date().getFullYear() === year;
              return (
                <div
                  key={day}
                  className="min-h-[100px] p-2 border-r border-b border-slate-200 last:border-r-0"
                >
                  <div
                    className={`text-sm font-medium mb-1 ${
                      isToday
                        ? "inline-flex items-center justify-center w-6 h-6 rounded-full bg-indigo-600 text-white"
                        : "text-slate-700"
                    }`}
                  >
                    {day}
                  </div>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 3).map((ev) => {
                      const color = ev.class?.color || (ev.type === "exam" ? "#ef4444" : ev.type === "holiday" ? "#10b981" : "#6366f1");
                      return (
                        <button
                          key={ev.id}
                          onClick={() => setSelected(ev)}
                          className="w-full text-left px-1.5 py-0.5 rounded text-xs text-white truncate hover:opacity-90"
                          style={{ backgroundColor: color }}
                        >
                          {ev.title}
                        </button>
                      );
                    })}
                    {dayEvents.length > 3 && (
                      <div className="text-xs text-slate-500 pl-1">
                        +{dayEvents.length - 3} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-5">
        <h3 className="font-semibold text-indigo-900 mb-2 flex items-center gap-2">
          <Upload className="w-4 h-4" />
          Automatic Schedule Import
        </h3>
        <p className="text-sm text-indigo-800 mb-3">
          Export your calendar from Google Calendar, Apple Calendar, or Outlook as a .ics file
          and upload it here. All your classes and events will be imported automatically.
        </p>
        <div className="text-xs text-indigo-700 space-y-1">
          <div>
            <strong>Google Calendar:</strong> Settings → Import & Export → Export your calendars
          </div>
          <div>
            <strong>Apple Calendar:</strong> File → Export → Export calendar
          </div>
          <div>
            <strong>Outlook:</strong> File → Save Calendar → Save as .ics
          </div>
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-slate-900">{selected.title}</h3>
                <p className="text-sm text-slate-500">
                  {new Date(selected.startAt).toLocaleDateString("en-PH", {
                    weekday: "long",
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </p>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>
            {selected.description && (
              <p className="text-slate-700 mb-4 whitespace-pre-wrap">
                {selected.description}
              </p>
            )}
            <div className="flex items-center gap-2 text-sm text-slate-600 mb-4">
              <CalIcon className="w-4 h-4" />
              {selected.allDay ? "All day" : `${new Date(selected.startAt).toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" })} – ${new Date(selected.endAt).toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" })}`}
            </div>
            <button
              onClick={() => deleteEvent(selected.id)}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100"
            >
              <Trash2 className="w-4 h-4" />
              Delete Event
            </button>
          </div>
        </div>
      )}

      {showModal && (
        <EventModal
          classes={classes}
          onClose={() => setShowModal(false)}
          onSave={(e) => {
            setEvents((prev) => [...prev, e]);
            setShowModal(false);
            toast("Event created");
          }}
        />
      )}
    </div>
  );
}

function EventModal({
  classes,
  onClose,
  onSave,
}: {
  classes: Class[];
  onClose: () => void;
  onSave: (e: EventWithClass) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [classId, setClassId] = useState("");
  const [type, setType] = useState<"class" | "exam" | "deadline" | "holiday" | "personal">("personal");
  const [startAt, setStartAt] = useState(new Date().toISOString().slice(0, 16));
  const [endAt, setEndAt] = useState(
    new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString().slice(0, 16),
  );
  const [allDay, setAllDay] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          classId: classId || null,
          type,
          startAt,
          endAt,
          allDay,
        }),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      onSave({ ...saved, class: classes.find((c) => c.id === saved.classId) ?? null });
    } catch {
      toast("Failed to create event", "error");
    }
    setLoading(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <h2 className="text-xl font-bold text-slate-900">New Event</h2>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Class (optional)
              </label>
              <select
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="">None</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="personal">Personal</option>
                <option value="exam">Exam</option>
                <option value="deadline">Deadline</option>
                <option value="holiday">Holiday</option>
                <option value="class">Class</option>
              </select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input
              id="allDay"
              type="checkbox"
              checked={allDay}
              onChange={(e) => setAllDay(e.target.checked)}
              className="w-4 h-4"
            />
            <label htmlFor="allDay" className="text-sm text-slate-700">
              All day event
            </label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Start
              </label>
              <input
                type={allDay ? "date" : "datetime-local"}
                value={startAt}
                onChange={(e) => setStartAt(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                End
              </label>
              <input
                type={allDay ? "date" : "datetime-local"}
                value={endAt}
                onChange={(e) => setEndAt(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:from-indigo-600 hover:to-purple-700 disabled:opacity-50"
            >
              {loading ? "Creating..." : "Create Event"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
