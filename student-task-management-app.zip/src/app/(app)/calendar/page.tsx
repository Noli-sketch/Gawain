import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { CalendarClient } from "./CalendarClient";

export default async function CalendarPage() {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");
  return <CalendarClient user={user} />;
}
