import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { Sidebar } from "@/components/Sidebar";
import { Toaster } from "@/components/Toaster";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar user={user} />
      <main className="flex-1 ml-0 md:ml-64">
        <div className="p-4 md:p-8 max-w-7xl mx-auto">{children}</div>
      </main>
      <Toaster />
    </div>
  );
}
