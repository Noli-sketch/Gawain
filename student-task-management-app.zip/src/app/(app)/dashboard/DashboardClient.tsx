"use client";

import { useEffect, useState } from "react";
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  BookOpen,
  Plus,
  Loader2,
  Inbox,
} from "lucide-react";
import Link from "next/link";
import type { User, Task, Event, Class } from "@/db/schema";
import {
  priorityDot,
  priorityLabel,
  relativeDue,
  statusLabel,
  taskTypeLabel,
} from "@/lib/utils";

type DashboardData = {
  stats: {
    total: number;
    upcoming: number;
    overdue: number;
    dueToday: number;
    dueThisWeek: number;
    completed: number;
    classes: number;
  };
  upcomingTasks: (Task & { class: Class | null })[];
  upcomingEvents: Event[];
  classes: Class[];
};

export function DashboardClient({ user }: { user: User }) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((d) => {
        setData(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? "Magandang umaga" : hour < 18 ? "Magandang hapon" : "Magandang gabi";

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">
            {greeting}, {user.name.split(" ")[0]}! 👋
          </h1>
          <p className="text-slate-600 mt-1">
            Here's what's happening with your studies today.
          </p>
        </div>
        <Link
          href="/tasks?new=1"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg font-medium hover:from-indigo-600 hover:to-purple-700 transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" />
          New Task
        </Link>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl p-5 border border-slate-200 animate-pulse"
            >
              <div className="h-4 bg-slate-200 rounded w-24 mb-3" />
              <div className="h-8 bg-slate-200 rounded w-16" />
            </div>
          ))}
        </div>
      ) : data ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={<AlertTriangle className="w-5 h-5" />}
              label="Overdue"
              value={data.stats.overdue}
              color="red"
            />
            <StatCard
              icon={<Clock className="w-5 h-5" />}
              label="Due Today"
              value={data.stats.dueToday}
              color="amber"
            />
            <StatCard
              icon={<Calendar className="w-5 h-5" />}
              label="This Week"
              value={data.stats.dueThisWeek}
              color="indigo"
            />
            <StatCard
              icon={<CheckCircle2 className="w-5 h-5" />}
              label="Completed"
              value={data.stats.completed}
              color="emerald"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-slate-900">Upcoming Tasks</h2>
                <Link
                  href="/tasks"
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  View all →
                </Link>
              </div>
              {data.upcomingTasks.length === 0 ? (
                <EmptyState
                  icon={<Inbox className="w-8 h-8" />}
                  title="All caught up!"
                  description="You have no upcoming tasks. Great job staying on top of things."
                />
              ) : (
                <div className="space-y-3">
                  {data.upcomingTasks.map((task) => {
                    const due = relativeDue(task.dueDate);
                    return (
                      <Link
                        key={task.id}
                        href={`/tasks?id=${task.id}`}
                        className="block p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all"
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-2 h-2 rounded-full mt-2 ${priorityDot(
                              task.priority,
                            )}`}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-slate-900 truncate">
                              {task.title}
                            </div>
                            <div className="flex items-center gap-2 mt-1 text-xs">
                              {task.class && (
                                <span
                                  className="px-2 py-0.5 rounded-full text-white font-medium"
                                  style={{ backgroundColor: task.class.color }}
                                >
                                  {task.class.code}
                                </span>
                              )}
                              <span className="text-slate-500">
                                {taskTypeLabel(task.type)}
                              </span>
                              <span className={`font-medium ${due.tone}`}>
                                {due.text}
                              </span>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <h2 className="font-semibold text-slate-900 mb-4">
                  Upcoming Events
                </h2>
                {data.upcomingEvents.length === 0 ? (
                  <EmptyState
                    icon={<Calendar className="w-8 h-8" />}
                    title="No events"
                    description="Nothing on your calendar yet."
                  />
                ) : (
                  <div className="space-y-3">
                    {data.upcomingEvents.slice(0, 4).map((ev) => (
                      <div key={ev.id} className="flex gap-3">
                        <div className="w-1 rounded-full bg-indigo-500" />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-slate-900 truncate">
                            {ev.title}
                          </div>
                          <div className="text-xs text-slate-500">
                            {new Date(ev.startAt).toLocaleDateString("en-PH", {
                              month: "short",
                              day: "numeric",
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
                <h3 className="font-semibold mb-1">Your Classes</h3>
                <p className="text-indigo-100 text-sm mb-4">
                  Enrolled in {data.classes.length} subjects this semester
                </p>
                <div className="flex flex-wrap gap-2">
                  {data.classes.slice(0, 5).map((c) => (
                    <span
                      key={c.id}
                      className="px-2.5 py-1 bg-white/20 backdrop-blur rounded-full text-xs font-medium"
                    >
                      {c.code}
                    </span>
                  ))}
                </div>
                <Link
                  href="/schedule"
                  className="mt-4 inline-block text-sm font-medium hover:underline"
                >
                  View schedule →
                </Link>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-12 text-slate-500">Failed to load dashboard</div>
      )}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: "red" | "amber" | "indigo" | "emerald";
}) {
  const colors = {
    red: "bg-red-50 text-red-600 border-red-100",
    amber: "bg-amber-50 text-amber-600 border-amber-100",
    indigo: "bg-indigo-50 text-indigo-600 border-indigo-100",
    emerald: "bg-emerald-50 text-emerald-600 border-emerald-100",
  };
  return (
    <div className="bg-white rounded-xl p-5 border border-slate-200">
      <div
        className={`inline-flex items-center justify-center w-10 h-10 rounded-lg border mb-3 ${colors[color]}`}
      >
        {icon}
      </div>
      <div className="text-2xl font-bold text-slate-900">{value}</div>
      <div className="text-sm text-slate-500">{label}</div>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="text-center py-10">
      <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-slate-100 text-slate-400 mb-3">
        {icon}
      </div>
      <h3 className="font-medium text-slate-900">{title}</h3>
      <p className="text-sm text-slate-500 mt-1">{description}</p>
    </div>
  );
}
