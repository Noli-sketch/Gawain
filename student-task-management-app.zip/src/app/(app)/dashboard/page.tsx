import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { DashboardClient } from "./DashboardClient";

export default async function DashboardPage() {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");

  return <DashboardClient user={user} />;
}
