"use client";

import { useEffect, useState } from "react";
import {
  Plus,
  BookOpen,
  Edit2,
  Trash2,
  MapPin,
  User as UserIcon,
  X,
} from "lucide-react";
import type { User, Class, ClassSchedule } from "@/db/schema";
import { dayShort, formatTimeRange, pickColor } from "@/lib/utils";
import { toast } from "@/components/Toaster";

type ClassWithSchedule = Class & { schedules: ClassSchedule[] };

const DAYS = ["M", "T", "W", "TH", "F", "SA", "SU"] as const;

export function ClassesClient({ user }: { user: User }) {
  const [classes, setClasses] = useState<ClassWithSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ClassWithSchedule | null>(null);

  function reload() {
    fetch("/api/classes")
      .then((r) => r.json())
      .then((d) => {
        setClasses(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }

  useEffect(reload, []);

  async function deleteClass(id: string) {
    if (!confirm("Remove this class? Tasks linked to it will remain.")) return;
    setClasses((prev) => prev.filter((c) => c.id !== id));
    try {
      await fetch(`/api/classes/${id}?id=${id}`, { method: "DELETE" });
      toast("Class removed");
    } catch {
      toast("Failed to delete", "error");
      reload();
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Classes</h1>
          <p className="text-slate-600 mt-1">
            Manage your enrolled subjects for this semester
          </p>
        </div>
        <button
          onClick={() => {
            setEditing(null);
            setShowModal(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg font-medium hover:from-indigo-600 hover:to-purple-700 transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Add Class
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl border border-slate-200 p-5 animate-pulse"
            >
              <div className="h-5 bg-slate-200 rounded w-24 mb-2" />
              <div className="h-4 bg-slate-200 rounded w-3/4 mb-4" />
              <div className="h-3 bg-slate-200 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : classes.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 text-slate-400 mb-4">
            <BookOpen className="w-8 h-8" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-1">No classes yet</h3>
          <p className="text-slate-500 text-sm mb-4">
            Add your subjects to start organizing your tasks
          </p>
          <button
            onClick={() => {
              setEditing(null);
              setShowModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4" />
            Add First Class
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {classes.map((cls) => (
            <div
              key={cls.id}
              className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <span
                  className="inline-block px-2.5 py-1 rounded-lg text-white text-sm font-bold"
                  style={{ backgroundColor: cls.color }}
                >
                  {cls.code}
                </span>
                <div className="flex gap-1">
                  <button
                    onClick={() => {
                      setEditing(cls);
                      setShowModal(true);
                    }}
                    className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteClass(cls.id)}
                    className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <h3 className="font-semibold text-slate-900 mb-3">{cls.name}</h3>
              <div className="space-y-1.5 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <UserIcon className="w-4 h-4 text-slate-400" />
                  <span className="truncate">{cls.professor}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <span className="truncate">{cls.room}</span>
                </div>
                <div className="text-xs text-slate-500 pt-1">
                  {cls.units} unit{cls.units !== 1 ? "s" : ""}
                </div>
              </div>
              {cls.schedules.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-100 space-y-1">
                  {cls.schedules
                    .slice()
                    .sort((a, b) => DAYS.indexOf(a.dayOfWeek as any) - DAYS.indexOf(b.dayOfWeek as any))
                    .map((s) => (
                      <div
                        key={s.id}
                        className="text-xs text-slate-600 flex items-center gap-2"
                      >
                        <span
                          className="w-8 text-center py-0.5 rounded text-white font-semibold"
                          style={{ backgroundColor: cls.color }}
                        >
                          {dayShort(s.dayOfWeek)}
                        </span>
                        <span>
                          {formatTimeRange(s.startTime, s.endTime)}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <ClassModal
          existing={editing}
          onClose={() => setShowModal(false)}
          onSave={(c) => {
            if (editing) {
              setClasses((prev) => prev.map((x) => (x.id === c.id ? c : x)));
              toast("Class updated");
            } else {
              setClasses((prev) => [...prev, c]);
              toast("Class added");
            }
            setShowModal(false);
          }}
        />
      )}
    </div>
  );
}

function ClassModal({
  existing,
  onClose,
  onSave,
}: {
  existing: ClassWithSchedule | null;
  onClose: () => void;
  onSave: (c: ClassWithSchedule) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [code, setCode] = useState(existing?.code || "");
  const [name, setName] = useState(existing?.name || "");
  const [professor, setProfessor] = useState(existing?.professor || "");
  const [room, setRoom] = useState(existing?.room || "");
  const [units, setUnits] = useState(existing?.units ?? 3);
  const [color, setColor] = useState(existing?.color || pickColor(Math.floor(Math.random() * 10)));
  const [schedules, setSchedules] = useState<
    Array<{ dayOfWeek: string; startTime: string; endTime: string }>
  >(
    existing?.schedules.map((s) => ({
      dayOfWeek: s.dayOfWeek,
      startTime: s.startTime.slice(0, 5),
      endTime: s.endTime.slice(0, 5),
    })) || [],
  );

  function addSchedule() {
    setSchedules((s) => [...s, { dayOfWeek: "M", startTime: "08:00", endTime: "09:00" }]);
  }

  function updateSchedule(i: number, patch: Record<string, string>) {
    setSchedules((s) => s.map((x, idx) => (idx === i ? { ...x, ...patch } : x)));
  }

  function removeSchedule(i: number) {
    setSchedules((s) => s.filter((_, idx) => idx !== i));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!code.trim() || !name.trim()) return;
    setLoading(true);
    try {
      const url = existing ? `/api/classes/${existing.id}` : "/api/classes";
      const method = existing ? "PATCH" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: existing?.id,
          code,
          name,
          professor,
          room,
          units,
          color,
          schedules: schedules.map((s) => ({
            ...s,
            startTime: s.startTime.length === 5 ? s.startTime + ":00" : s.startTime,
            endTime: s.endTime.length === 5 ? s.endTime + ":00" : s.endTime,
          })),
        }),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      onSave(saved);
    } catch {
      toast("Failed to save class", "error");
    }
    setLoading(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <h2 className="text-xl font-bold text-slate-900">
            {existing ? "Edit Class" : "Add Class"}
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Course Code *
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="CMSC 127"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Units
              </label>
              <input
                type="number"
                min="1"
                max="6"
                value={units}
                onChange={(e) => setUnits(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Course Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Introduction to Database Systems"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Professor
            </label>
            <input
              type="text"
              value={professor}
              onChange={(e) => setProfessor(e.target.value)}
              placeholder="Prof. Juan Dela Cruz"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Room
            </label>
            <input
              type="text"
              value={room}
              onChange={(e) => setRoom(e.target.value)}
              placeholder="Science Hall 301"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Color
            </label>
            <div className="flex flex-wrap gap-2">
              {["#6366f1", "#ec4899", "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6", "#ef4444", "#14b8a6", "#f97316", "#06b6d4"].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-lg transition-all ${
                    color === c ? "ring-2 ring-offset-2 ring-slate-400" : ""
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-slate-700">
                Schedule
              </label>
              <button
                type="button"
                onClick={addSchedule}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
              >
                + Add time slot
              </button>
            </div>
            <div className="space-y-2">
              {schedules.map((s, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <select
                    value={s.dayOfWeek}
                    onChange={(e) => updateSchedule(i, { dayOfWeek: e.target.value })}
                    className="px-2 py-1.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    {DAYS.map((d) => (
                      <option key={d} value={d}>
                        {dayShort(d)}
                      </option>
                    ))}
                  </select>
                  <input
                    type="time"
                    value={s.startTime}
                    onChange={(e) => updateSchedule(i, { startTime: e.target.value })}
                    className="flex-1 px-2 py-1.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                  <span className="text-slate-400">–</span>
                  <input
                    type="time"
                    value={s.endTime}
                    onChange={(e) => updateSchedule(i, { endTime: e.target.value })}
                    className="flex-1 px-2 py-1.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                  <button
                    type="button"
                    onClick={() => removeSchedule(i)}
                    className="p-1.5 text-slate-400 hover:text-red-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {schedules.length === 0 && (
                <p className="text-sm text-slate-500 py-2">No schedule set</p>
              )}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:from-indigo-600 hover:to-purple-700 disabled:opacity-50"
            >
              {loading ? "Saving..." : existing ? "Update" : "Add Class"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
