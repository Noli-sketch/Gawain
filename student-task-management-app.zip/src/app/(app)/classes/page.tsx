import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth";
import { ClassesClient } from "./ClassesClient";

export default async function ClassesPage() {
  const { user } = await getCurrentSession();
  if (!user) redirect("/login");
  return <ClassesClient user={user} />;
}
