import { NextResponse } from "next/server";
import { eq, and, gte, lte, count, sql } from "drizzle-orm";
import { db } from "@/db";
import { tasks, classes, events } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await requireUser();

    const now = new Date();
    const in7 = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);

    const allTasks = await db
      .select({ task: tasks, class: classes })
      .from(tasks)
      .leftJoin(classes, eq(tasks.classId, classes.id))
      .where(eq(tasks.userId, user.id));

    const upcoming = allTasks
      .filter((r) => r.task.status !== "done")
      .sort((a, b) => a.task.dueDate.getTime() - b.task.dueDate.getTime())
      .slice(0, 6)
      .map((r) => ({ ...r.task, class: r.class }));

    const overdue = allTasks.filter(
      (r) => r.task.status !== "done" && r.task.dueDate < now,
    ).length;
    const dueToday = allTasks.filter((r) => {
      if (r.task.status === "done") return false;
      return (
        r.task.dueDate >= todayStart && r.task.dueDate < todayEnd
      );
    }).length;
    const dueThisWeek = allTasks.filter((r) => {
      if (r.task.status === "done") return false;
      return r.task.dueDate >= now && r.task.dueDate <= in7;
    }).length;
    const completed = allTasks.filter((r) => r.task.status === "done").length;

    const classesList = await db
      .select()
      .from(classes)
      .where(and(eq(classes.userId, user.id), eq(classes.archived, false)));

    const upcomingEvents = await db
      .select()
      .from(events)
      .where(and(eq(events.userId, user.id), gte(events.startAt, now)))
      .orderBy(events.startAt)
      .limit(6);

    return NextResponse.json({
      stats: {
        total: allTasks.length,
        upcoming: upcoming.length,
        overdue,
        dueToday,
        dueThisWeek,
        completed,
        classes: classesList.length,
      },
      upcomingTasks: upcoming,
      upcomingEvents,
      classes: classesList,
    });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
