import { NextResponse } from "next/server";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { tasks, classes } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function PATCH(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { id, ...updates } = body;

    const existing = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, user.id)))
      .limit(1);
    if (existing.length === 0) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const patch: Record<string, any> = { updatedAt: new Date() };
    if (updates.title !== undefined) patch.title = updates.title;
    if (updates.description !== undefined) patch.description = updates.description;
    if (updates.type !== undefined) patch.type = updates.type;
    if (updates.priority !== undefined) patch.priority = updates.priority;
    if (updates.status !== undefined) {
      patch.status = updates.status;
      patch.completedAt = updates.status === "done" ? new Date() : null;
    }
    if (updates.classId !== undefined) patch.classId = updates.classId || null;
    if (updates.dueDate !== undefined) patch.dueDate = new Date(updates.dueDate);

    await db.update(tasks).set(patch).where(eq(tasks.id, id));

    const row = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
    const cls = row[0].classId
      ? await db.select().from(classes).where(eq(classes.id, row[0].classId)).limit(1)
      : [];
    return NextResponse.json({ ...row[0], class: cls[0] ?? null });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, user.id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
