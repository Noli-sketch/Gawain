import { NextResponse } from "next/server";
import { eq, and, desc } from "drizzle-orm";
import { v4 as uuid } from "uuid";
import { db } from "@/db";
import { tasks, classes } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const classId = searchParams.get("classId");
    const status = searchParams.get("status");

    const conditions = [eq(tasks.userId, user.id)];
    if (classId) conditions.push(eq(tasks.classId, classId));
    if (status && status !== "all")
      conditions.push(eq(tasks.status, status as any));

    const rows = await db
      .select({
        task: tasks,
        class: classes,
      })
      .from(tasks)
      .leftJoin(classes, eq(tasks.classId, classes.id))
      .where(and(...conditions))
      .orderBy(tasks.dueDate);

    return NextResponse.json(rows.map((r) => ({ ...r.task, class: r.class })));
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const id = uuid();
    await db.insert(tasks).values({
      id,
      userId: user.id,
      classId: body.classId || null,
      title: body.title,
      description: body.description || null,
      type: body.type || "assignment",
      priority: body.priority || "medium",
      status: body.status || "todo",
      dueDate: new Date(body.dueDate),
    });
    const row = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
    const cls = body.classId
      ? await db.select().from(classes).where(eq(classes.id, body.classId)).limit(1)
      : [];
    return NextResponse.json({ ...row[0], class: cls[0] ?? null });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
