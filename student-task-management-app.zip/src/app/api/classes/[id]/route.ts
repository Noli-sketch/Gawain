import { NextResponse } from "next/server";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { classes, classSchedules } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function PATCH(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { id, schedules, ...updates } = body;

    const existing = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, id), eq(classes.userId, user.id)))
      .limit(1);
    if (existing.length === 0)
      return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (Object.keys(updates).length > 0) {
      await db.update(classes).set(updates).where(eq(classes.id, id));
    }

    if (Array.isArray(schedules)) {
      await db.delete(classSchedules).where(eq(classSchedules.classId, id));
      const { v4: uid } = await import("uuid");
      for (const s of schedules) {
        await db.insert(classSchedules).values({
          id: uid(),
          classId: id,
          dayOfWeek: s.dayOfWeek,
          startTime: s.startTime,
          endTime: s.endTime,
        });
      }
    }

    const row = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
    const scheds = await db
      .select()
      .from(classSchedules)
      .where(eq(classSchedules.classId, id));
    return NextResponse.json({ ...row[0], schedules: scheds });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db
      .update(classes)
      .set({ archived: true })
      .where(and(eq(classes.id, id), eq(classes.userId, user.id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
