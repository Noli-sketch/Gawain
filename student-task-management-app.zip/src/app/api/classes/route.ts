import { NextResponse } from "next/server";
import { eq, and, inArray } from "drizzle-orm";
import { v4 as uuid } from "uuid";
import { db } from "@/db";
import { classes, classSchedules } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db
      .select()
      .from(classes)
      .where(and(eq(classes.userId, user.id), eq(classes.archived, false)));
    const schedules = await db
      .select()
      .from(classSchedules)
      .where(
        rows.length > 0
          ? inArray(classSchedules.classId, rows.map((c) => c.id))
          : eq(classSchedules.classId, "__none__"),
      );

    const result = rows.map((c) => ({
      ...c,
      schedules: schedules.filter((s) => s.classId === c.id),
    }));
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const id = uuid();
    await db.insert(classes).values({
      id,
      userId: user.id,
      code: body.code,
      name: body.name,
      professor: body.professor || "TBA",
      room: body.room || "TBA",
      color: body.color || "#6366f1",
      units: body.units || 3,
    });
    if (body.schedules && Array.isArray(body.schedules)) {
      for (const s of body.schedules) {
        await db.insert(classSchedules).values({
          id: uuid(),
          classId: id,
          dayOfWeek: s.dayOfWeek,
          startTime: s.startTime,
          endTime: s.endTime,
        });
      }
    }
    const row = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
    return NextResponse.json({ ...row[0], schedules: body.schedules || [] });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
