import { NextResponse } from "next/server";
import { eq, and, gte, lte } from "drizzle-orm";
import { v4 as uuid } from "uuid";
import { db } from "@/db";
import { events, classes } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { parseICS } from "@/lib/utils";

export async function GET(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const start = searchParams.get("start");
    const end = searchParams.get("end");

    const conditions: any[] = [eq(events.userId, user.id)];
    if (start) conditions.push(gte(events.startAt, new Date(start)));
    if (end) conditions.push(lte(events.startAt, new Date(end)));

    const rows = await db
      .select({ event: events, class: classes })
      .from(events)
      .leftJoin(classes, eq(events.classId, classes.id))
      .where(and(...conditions))
      .orderBy(events.startAt);
    return NextResponse.json(
      rows.map((r) => ({ ...r.event, class: r.class })),
    );
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const contentType = req.headers.get("content-type") || "";

    // ICS file upload
    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file") as File | null;
      if (!file) return NextResponse.json({ error: "No file" }, { status: 400 });
      const text = await file.text();
      const parsed = parseICS(text);
      const inserted: number = parsed.length;
      for (const ev of parsed) {
        await db.insert(events).values({
          id: uuid(),
          userId: user.id,
          title: ev.summary,
          description: ev.description || ev.location || null,
          type: "personal",
          startAt: ev.start,
          endAt: ev.end,
          allDay: ev.allDay,
        });
      }
      return NextResponse.json({ imported: inserted });
    }

    // JSON create
    const body = await req.json();
    const id = uuid();
    await db.insert(events).values({
      id,
      userId: user.id,
      classId: body.classId || null,
      title: body.title,
      description: body.description || null,
      type: body.type || "personal",
      startAt: new Date(body.startAt),
      endAt: new Date(body.endAt),
      allDay: body.allDay || false,
    });
    const row = await db.select().from(events).where(eq(events.id, id)).limit(1);
    return NextResponse.json(row[0]);
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
