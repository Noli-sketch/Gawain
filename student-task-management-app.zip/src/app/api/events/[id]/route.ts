import { NextResponse } from "next/server";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { events } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function PATCH(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const { id, ...updates } = body;
    const existing = await db
      .select()
      .from(events)
      .where(and(eq(events.id, id), eq(events.userId, user.id)))
      .limit(1);
    if (existing.length === 0)
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    const patch: Record<string, any> = {};
    if (updates.title !== undefined) patch.title = updates.title;
    if (updates.description !== undefined) patch.description = updates.description;
    if (updates.type !== undefined) patch.type = updates.type;
    if (updates.startAt !== undefined) patch.startAt = new Date(updates.startAt);
    if (updates.endAt !== undefined) patch.endAt = new Date(updates.endAt);
    if (updates.allDay !== undefined) patch.allDay = updates.allDay;
    await db.update(events).set(patch).where(eq(events.id, id));
    const row = await db.select().from(events).where(eq(events.id, id)).limit(1);
    return NextResponse.json(row[0]);
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db
      .delete(events)
      .where(and(eq(events.id, id), eq(events.userId, user.id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
