import { NextResponse } from "next/server";
import { eq, and, inArray } from "drizzle-orm";
import { db } from "@/db";
import { classes, classSchedules } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await requireUser();
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.userId, user.id), eq(classes.archived, false)));
    if (cls.length === 0) return NextResponse.json([]);
    const scheds = await db
      .select()
      .from(classSchedules)
      .where(inArray(classSchedules.classId, cls.map((c) => c.id)));
    const map = new Map<string, typeof cls[0] & { schedules: typeof scheds }>();
    for (const c of cls) map.set(c.id, { ...c, schedules: [] });
    for (const s of scheds) {
      const entry = map.get(s.classId);
      if (entry) entry.schedules.push(s);
    }
    return NextResponse.json(Array.from(map.values()));
  } catch (e) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
