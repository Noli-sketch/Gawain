import { NextResponse } from "next/server";
import {
  clearSessionCookie,
  destroySession,
  getCurrentSession,
} from "@/lib/auth";

export async function POST() {
  const { session } = await getCurrentSession();
  if (session) {
    await destroySession(session.id);
  }
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
