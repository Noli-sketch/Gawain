import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { v4 as uuid } from "uuid";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  hashPassword,
  setSessionCookie,
  verifyPassword,
} from "@/lib/auth";

export async function POST(req: Request) {
  const body = await req.json();
  const { mode, email, password, name, university, course, yearLevel } = body;

  if (!email || !password) {
    return NextResponse.json({ error: "Email and password required" }, { status: 400 });
  }

  if (mode === "register") {
    if (!name || !university || !course || !yearLevel) {
      return NextResponse.json({ error: "All fields required" }, { status: 400 });
    }
    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "Email already registered" }, { status: 400 });
    }
    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 });
    }
    const colors = ["#6366f1", "#ec4899", "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6"];
    const id = uuid();
    const passwordHash = await hashPassword(password);
    await db.insert(users).values({
      id,
      name,
      email,
      passwordHash,
      university,
      course,
      yearLevel,
      avatarColor: colors[Math.floor(Math.random() * colors.length)],
    });
    const sessionId = await createSession(id);
    await setSessionCookie(sessionId);
    return NextResponse.json({ ok: true, redirect: "/dashboard" });
  }

  // login
  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (rows.length === 0) {
    return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
  }
  const user = rows[0];
  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) {
    return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
  }
  const sessionId = await createSession(user.id);
  await setSessionCookie(sessionId);
  return NextResponse.json({ ok: true, redirect: "/dashboard" });
}
