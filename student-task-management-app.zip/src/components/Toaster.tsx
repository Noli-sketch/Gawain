"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import { CheckCircle2, AlertCircle, X } from "lucide-react";

type Toast = {
  id: string;
  message: string;
  type: "success" | "error" | "info";
};

const listeners = new Set<() => void>();
let toasts: Toast[] = [];

function emit() {
  listeners.forEach((l) => l());
}

export function toast(message: string, type: Toast["type"] = "success") {
  const id = Math.random().toString(36).slice(2);
  toasts = [...toasts, { id, message, type }];
  emit();
  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    emit();
  }, 3500);
}

export function dismissToast(id: string) {
  toasts = toasts.filter((t) => t.id !== id);
  emit();
}

function useToasts() {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => toasts,
    () => [],
  );
}

export function Toaster() {
  const list = useToasts();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return (
    <div className="fixed bottom-4 right-4 z-[100] space-y-2 max-w-sm">
      {list.map((t) => (
        <div
          key={t.id}
          className={`flex items-start gap-3 p-4 rounded-lg shadow-lg border animate-in slide-in-from-right ${
            t.type === "success"
              ? "bg-white border-emerald-200 text-emerald-900"
              : t.type === "error"
              ? "bg-white border-red-200 text-red-900"
              : "bg-white border-slate-200 text-slate-900"
          }`}
        >
          {t.type === "success" ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle
              className={`w-5 h-5 shrink-0 mt-0.5 ${
                t.type === "error" ? "text-red-500" : "text-indigo-500"
              }`}
            />
          )}
          <div className="flex-1 text-sm font-medium">{t.message}</div>
          <button
            onClick={() => dismissToast(t.id)}
            className="text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
