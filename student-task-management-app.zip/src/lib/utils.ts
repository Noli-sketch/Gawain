export function cn(...inputs: (string | boolean | undefined | null)[]) {
  return inputs.filter(Boolean).join(" ");
}

const COLORS = [
  "#6366f1",
  "#ec4899",
  "#f59e0b",
  "#10b981",
  "#3b82f6",
  "#8b5cf6",
  "#ef4444",
  "#14b8a6",
  "#f97316",
  "#06b6d4",
];

export function pickColor(index: number): string {
  return COLORS[index % COLORS.length];
}

export function formatTime(time: string): string {
  // "HH:MM:SS" or "HH:MM"
  const parts = time.split(":");
  const h = parseInt(parts[0], 10);
  const m = parts[1] || "00";
  const suffix = h >= 12 ? "PM" : "AM";
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${m} ${suffix}`;
}

export function formatTimeRange(start: string, end: string): string {
  return `${formatTime(start)} – ${formatTime(end)}`;
}

export function dayLabel(code: string): string {
  const map: Record<string, string> = {
    M: "Monday",
    T: "Tuesday",
    W: "Wednesday",
    TH: "Thursday",
    F: "Friday",
    SA: "Saturday",
    SU: "Sunday",
  };
  return map[code] ?? code;
}

export function dayShort(code: string): string {
  const map: Record<string, string> = {
    M: "Mon",
    T: "Tue",
    W: "Wed",
    TH: "Thu",
    F: "Fri",
    SA: "Sat",
    SU: "Sun",
  };
  return map[code] ?? code;
}

export function priorityLabel(p: string): string {
  return (
    { low: "Low", medium: "Medium", high: "High", urgent: "Urgent" }[p] ?? p
  );
}

export function priorityDot(p: string): string {
  return (
    {
      low: "bg-slate-300",
      medium: "bg-sky-400",
      high: "bg-orange-400",
      urgent: "bg-red-500",
    }[p] ?? "bg-slate-400"
  );
}

export function statusLabel(s: string): string {
  return { todo: "To do", in_progress: "In progress", done: "Done" }[s] ?? s;
}

export function taskTypeLabel(t: string): string {
  return (
    {
      assignment: "Assignment",
      exam: "Exam",
      quiz: "Quiz",
      project: "Project",
      report: "Report",
      reading: "Reading",
      other: "Other",
    }[t] ?? t
  );
}

export function initials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? "")
    .join("");
}

export function relativeDue(due: Date): { text: string; tone: string } {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const d = new Date(due.getFullYear(), due.getMonth(), due.getDate());
  const diff = Math.round((d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diff < 0) return { text: `${Math.abs(diff)}d overdue`, tone: "text-red-600" };
  if (diff === 0) return { text: "Due today", tone: "text-amber-600" };
  if (diff === 1) return { text: "Due tomorrow", tone: "text-amber-600" };
  if (diff <= 7) return { text: `Due in ${diff} days`, tone: "text-slate-700" };
  return { text: `Due ${d.toLocaleDateString("en-PH", { month: "short", day: "numeric" })}`, tone: "text-slate-500" };
}

// Minimal ICS parser for common calendar apps (Google Calendar, Apple Calendar, Outlook)
export function parseICS(text: string): Array<{
  summary: string;
  description?: string;
  start: Date;
  end: Date;
  location?: string;
  allDay: boolean;
}> {
  const out: Array<{
    summary: string;
    description?: string;
    start: Date;
    end: Date;
    location?: string;
    allDay: boolean;
  }> = [];
  // Unfold lines (RFC 5545 continuation lines start with space/tab)
  const unfolded = text.replace(/\r\n[ \t]/g, "").replace(/\r/g, "");
  const events = unfolded.split("BEGIN:VEVENT");
  for (const ev of events.slice(1)) {
    const lines = ev.split("\n");
    let summary = "";
    let description = "";
    let location = "";
    let dtstart = "";
    let dtend = "";
    let allDay = false;
    for (const line of lines) {
      if (line.startsWith("SUMMARY")) {
        summary = line.split(":").slice(1).join(":").trim();
      } else if (line.startsWith("DESCRIPTION")) {
        description = line.split(":").slice(1).join(":").trim();
      } else if (line.startsWith("LOCATION")) {
        location = line.split(":").slice(1).join(":").trim();
      } else if (line.startsWith("DTSTART")) {
        dtstart = line.split(":").slice(1).join(":").trim();
        if (line.includes("VALUE=DATE") && dtstart.length === 8) allDay = true;
      } else if (line.startsWith("DTEND")) {
        dtend = line.split(":").slice(1).join(":").trim();
      }
    }
    if (!summary || !dtstart) continue;
    const start = parseICSDate(dtstart);
    const end = parseICSDate(dtend || dtstart);
    if (!start) continue;
    out.push({
      summary: unescapeICS(summary),
      description: description ? unescapeICS(description) : undefined,
      start,
      end: end ?? start,
      location: location ? unescapeICS(location) : undefined,
      allDay,
    });
  }
  return out;
}

function parseICSDate(value: string): Date | null {
  // formats: 20250101, 20250101T120000, 20250101T120000Z
  if (!value) return null;
  const v = value.replace(/[-:]/g, ""); // tolerant
  if (v.length === 8) {
    const y = parseInt(v.slice(0, 4), 10);
    const m = parseInt(v.slice(4, 6), 10) - 1;
    const d = parseInt(v.slice(6, 8), 10);
    return new Date(y, m, d);
  }
  const iso =
    v.slice(0, 4) +
    "-" +
    v.slice(4, 6) +
    "-" +
    v.slice(6, 8) +
    "T" +
    v.slice(9, 11) +
    ":" +
    v.slice(11, 13) +
    ":" +
    (v.slice(13, 15) || "00") +
    (v.endsWith("Z") ? "Z" : "");
  return new Date(iso);
}

function unescapeICS(s: string): string {
  return s
    .replace(/\\n/g, "\n")
    .replace(/\\,/g, ",")
    .replace(/\\;/g, ";")
    .replace(/\\\\/g, "\\");
}
