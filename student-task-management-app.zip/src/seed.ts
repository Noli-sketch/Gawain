import "dotenv/config";
import { db } from "./db";
import {
  users,
  classes,
  classSchedules,
  events,
  tasks,
} from "./db/schema";
import { hashPassword } from "./lib/auth";
import { v4 as uuid } from "uuid";
import { eq } from "drizzle-orm";

const DEMO_EMAIL = "demo@up.edu.ph";
const DEMO_PASSWORD = "demo1234";

async function seed() {
  console.log("🌱 Seeding database...");

  const existing = await db
    .select()
    .from(users)
    .where(eq(users.email, DEMO_EMAIL));
  if (existing.length > 0) {
    console.log("Demo user already exists, skipping seed");
    return;
  }

  const userId = uuid();
  const passwordHash = await hashPassword(DEMO_PASSWORD);
  await db.insert(users).values({
    id: userId,
    name: "Maria Santos",
    email: DEMO_EMAIL,
    passwordHash,
    university: "University of the Philippines Diliman",
    course: "BS Computer Science",
    yearLevel: "3rd Year",
    semester: "1st Semester, AY 2025-2026",
    avatarColor: "#6366f1",
  });

  console.log("✓ Created demo user");

  const classData = [
    {
      code: "CMSC 127",
      name: "Introduction to Database Systems",
      professor: "Prof. Ricardo Santos",
      room: "Science Hall 301",
      color: "#6366f1",
      units: 3,
    },
    {
      code: "CMSC 128",
      name: "Software Engineering I",
      professor: "Engr. Ana Reyes",
      room: "Albert Hall 205",
      color: "#ec4899",
      units: 3,
    },
    {
      code: "CMSC 131",
      name: "Principles of Programming Languages",
      professor: "Dr. Miguel Cruz",
      room: "Albert Hall 203",
      color: "#f59e0b",
      units: 3,
    },
    {
      code: "GE Filipino 3",
      name: "Komunikasyon sa Akademikong Filipino",
      professor: "Gng. Patricia Lim",
      room: "Palma Hall 201",
      color: "#10b981",
      units: 3,
    },
    {
      code: "NSTP 2",
      name: "National Service Training Program - CWTS",
      professor: "Mr. Jose Garcia",
      room: "Sunken Garden",
      color: "#3b82f6",
      units: 3,
    },
    {
      code: "PE 3",
      name: "Physical Education - Swimming",
      professor: "Coach Miguel Torres",
      room: "University Gym Pool",
      color: "#8b5cf6",
      units: 2,
    },
  ];

  const classIds: string[] = [];
  for (const cls of classData) {
    const id = uuid();
    classIds.push(id);
    await db.insert(classes).values({ id, userId, ...cls });
  }

  const scheduleData = [
    { classIndex: 0, dayOfWeek: "M", startTime: "08:00:00", endTime: "09:00:00" },
    { classIndex: 0, dayOfWeek: "W", startTime: "08:00:00", endTime: "09:00:00" },
    { classIndex: 0, dayOfWeek: "F", startTime: "08:00:00", endTime: "09:00:00" },
    { classIndex: 1, dayOfWeek: "T", startTime: "10:00:00", endTime: "11:30:00" },
    { classIndex: 1, dayOfWeek: "TH", startTime: "10:00:00", endTime: "11:30:00" },
    { classIndex: 2, dayOfWeek: "M", startTime: "13:00:00", endTime: "14:00:00" },
    { classIndex: 2, dayOfWeek: "W", startTime: "13:00:00", endTime: "14:00:00" },
    { classIndex: 2, dayOfWeek: "F", startTime: "13:00:00", endTime: "14:00:00" },
    { classIndex: 3, dayOfWeek: "T", startTime: "14:00:00", endTime: "15:30:00" },
    { classIndex: 3, dayOfWeek: "TH", startTime: "14:00:00", endTime: "15:30:00" },
    { classIndex: 4, dayOfWeek: "SA", startTime: "08:00:00", endTime: "12:00:00" },
    { classIndex: 5, dayOfWeek: "SA", startTime: "13:00:00", endTime: "15:00:00" },
  ];

  for (const sched of scheduleData) {
    await db.insert(classSchedules).values({
      id: uuid(),
      classId: classIds[sched.classIndex],
      dayOfWeek: sched.dayOfWeek as "M" | "T" | "W" | "TH" | "F" | "SA" | "SU",
      startTime: sched.startTime,
      endTime: sched.endTime,
    });
  }

  const now = new Date();
  const taskData = [
    {
      classIndex: 0,
      title: "Database Design Project - ER Diagram",
      description:
        "Design an ER diagram for a library management system. Include at least 5 entities with proper relationships and cardinality.",
      type: "project" as const,
      priority: "high" as const,
      status: "in_progress" as const,
      dueDays: 3,
    },
    {
      classIndex: 0,
      title: "SQL Queries Assignment",
      description: "Complete exercises 1-10 from Chapter 5. Submit SQL files via UVLe.",
      type: "assignment" as const,
      priority: "medium" as const,
      status: "todo" as const,
      dueDays: 5,
    },
    {
      classIndex: 1,
      title: "Software Requirements Document",
      description:
        "Write SRS for the group project. Use IEEE 830 template. Include functional and non-functional requirements.",
      type: "report" as const,
      priority: "high" as const,
      status: "in_progress" as const,
      dueDays: 7,
    },
    {
      classIndex: 1,
      title: "Midterm Exam Review",
      description:
        "Review chapters 1-6 of Software Engineering textbook. Focus on agile methodologies and UML diagrams.",
      type: "reading" as const,
      priority: "urgent" as const,
      status: "todo" as const,
      dueDays: 2,
    },
    {
      classIndex: 2,
      title: "Programming Languages Quiz",
      description: "Quiz on functional programming concepts and Haskell basics.",
      type: "quiz" as const,
      priority: "medium" as const,
      status: "todo" as const,
      dueDays: 4,
    },
    {
      classIndex: 3,
      title: "Sanaysay tungkol sa Kultura ng Pilipinas",
      description:
        "Magsulat ng sanaysay (1000-1500 salita) tungkol sa isang aspeto ng kulturang Pilipino.",
      type: "assignment" as const,
      priority: "medium" as const,
      status: "todo" as const,
      dueDays: 6,
    },
    {
      classIndex: 3,
      title: "Presentasyon sa Klase",
      description: "Mag-present ng pananaliksik tungkol sa wikang Filipino sa social media.",
      type: "report" as const,
      priority: "high" as const,
      status: "todo" as const,
      dueDays: 10,
    },
    {
      classIndex: 4,
      title: "Community Service Report",
      description:
        "Submit documentation of 20 hours community service. Include photos and reflection paper.",
      type: "report" as const,
      priority: "low" as const,
      status: "todo" as const,
      dueDays: 14,
    },
    {
      classIndex: 5,
      title: "Swimming Skills Test",
      description: "Final swimming test - 50m freestyle and basic survival skills.",
      type: "exam" as const,
      priority: "medium" as const,
      status: "todo" as const,
      dueDays: 12,
    },
  ];

  for (const task of taskData) {
    const dueDate = new Date(now);
    dueDate.setDate(dueDate.getDate() + task.dueDays);
    dueDate.setHours(23, 59, 0, 0);

    await db.insert(tasks).values({
      id: uuid(),
      userId,
      classId: classIds[task.classIndex],
      title: task.title,
      description: task.description,
      type: task.type,
      priority: task.priority,
      status: task.status,
      dueDate,
    });
  }

  const eventData = [
    {
      title: "Midterm Exams Week",
      description: "All midterm examinations",
      type: "exam" as const,
      daysFromNow: 14,
      allDay: true,
      duration: 5,
    },
    {
      title: "Bonifacio Day",
      description: "Regular holiday - No classes",
      type: "holiday" as const,
      daysFromNow: 20,
      allDay: true,
      duration: 1,
    },
    {
      title: "UP Fair",
      description: "Annual university fair at Sunken Garden",
      type: "personal" as const,
      daysFromNow: 25,
      allDay: false,
      duration: 1,
      startHour: 16,
    },
    {
      title: "ACM Programming Contest",
      description: "Inter-university programming competition",
      type: "personal" as const,
      daysFromNow: 8,
      allDay: false,
      duration: 1,
      startHour: 9,
    },
    {
      title: "Group Project Meeting",
      description: "CMSC 128 project planning",
      type: "personal" as const,
      daysFromNow: 2,
      allDay: false,
      duration: 1,
      startHour: 15,
    },
  ];

  for (const ev of eventData) {
    const startAt = new Date(now);
    startAt.setDate(startAt.getDate() + ev.daysFromNow);
    if (!ev.allDay && ev.startHour) {
      startAt.setHours(ev.startHour, 0, 0, 0);
    } else {
      startAt.setHours(0, 0, 0, 0);
    }

    const endAt = new Date(startAt);
    if (ev.allDay) {
      endAt.setDate(endAt.getDate() + ev.duration);
    } else {
      endAt.setHours(startAt.getHours() + 2, 0, 0, 0);
    }

    await db.insert(events).values({
      id: uuid(),
      userId,
      title: ev.title,
      description: ev.description,
      type: ev.type,
      startAt,
      endAt,
      allDay: ev.allDay,
    });
  }

  console.log("✓ Created tasks and events");
  console.log("\n✅ Seeding complete!");
  console.log(`\n📧 Login credentials:`);
  console.log(`   Email: ${DEMO_EMAIL}`);
  console.log(`   Password: ${DEMO_PASSWORD}`);
}

seed()
  .catch((err) => {
    console.error("❌ Seeding failed:", err);
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  });
